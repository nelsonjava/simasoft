
INSERT INTO users(id, name) VALUES(1, 'admin');